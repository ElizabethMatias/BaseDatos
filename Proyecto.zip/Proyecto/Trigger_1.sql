CREATE TRIGGER T_enviosInternacionales 
ON Internacional FOR INSERT AS
    DECLARE @Codigo VARCHAR(8)
    DECLARE @CodigoPaquete VARCHAR(8)
    SELECT * FROM INSERTED
    SET @Codigo = (SELECT Codigo FROM INSERTED)
    SET @CodigoPaquete = (SELECT Codigo FROM Nacional WHERE Codigo = @Codigo)
        IF @Codigo = @CodigoPaquete
            BEGIN 
            PRINT 'Error, este paquete ya esta en nacional'
            ROLLBACK
        END
    ELSE
        BEGIN
            PRINT 'Se ha realizado la inserción'
        END

DROP TRIGGER T_enviosInternacionales 

SELECT * FROM Nacional;
SELECT * FROM Internacional;
SELECT * FROM Paquete;


--Internacional
INSERT INTO Internacional VALUES ('Francesa', '04/02/2021', 'HJ_72456', 121);
INSERT INTO Internacional VALUES ('Francesa', '04/02/2021', 'WR_73254', 121);

--DELETE FROM Internacional WHERE Codigo = 'HJ_72456' 









-- DELETE FROM Nacional
-- DELETE FROM Internacional
-- DELETE FROM Paquete

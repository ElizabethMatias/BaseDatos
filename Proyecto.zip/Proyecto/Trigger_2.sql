CREATE TRIGGER T_enviosNacionales 
ON Nacional FOR INSERT AS
    DECLARE @Codigo VARCHAR(8)
    DECLARE @CodigoPaquete VARCHAR(8)
    SET @Codigo = (SELECT Codigo FROM INSERTED)
    SET @CodigoPaquete = (SELECT Codigo FROM Internacional WHERE Codigo = @Codigo)
        IF @Codigo = @CodigoPaquete
            BEGIN 
                PRINT 'Error, este paquete ya esta en internacional'
            ROLLBACK
        END
    ELSE
        BEGIN
            PRINT 'Se ha realizado la inserción'
        END

DROP TRIGGER T_enviosNacionales 

SELECT * FROM Nacional;
SELECT * FROM Internacional;
SELECT * FROM Paquete;

--Nacional
INSERT INTO Nacional VALUES ('NW_61663', 'Zenzontle','GADM070860623', 56);
INSERT INTO Nacional VALUES ( 'XC_62672', 'Trueno','CAPR161280872', 56);


INSERT INTO Internacional VALUES ('Francesa', '04/02/2021', 'XC_62672', 121);






-- DELETE FROM Nacional
-- DELETE FROM Internacional
-- DELETE FROM Paquete

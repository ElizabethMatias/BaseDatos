-- Crear otro Disparador para la tabla Camión
-- Que no permita dar de alta camiones con cargas menores a 250 kg o mayores a 1250 kg
-- Deberá mandar un mensaje de la razón por la cual no se pudo ingresar camiones que no
-- cumplan con lo establecida
CREATE TRIGGER T_pesoCamiones 
ON Camion FOR INSERT, UPDATE AS
    DECLARE @Carga_MAX REAL
    SET @Carga_MAX  = (SELECT Carga_MAX FROM INSERTED)
    IF @Carga_MAX < 250 
        BEGIN
            PRINT '¡No se puede ingresar un camión con carga tan BAJA!' 
            ROLLBACK
        END
    ELSE IF @Carga_MAX > 1250
        BEGIN
            PRINT '¡No se puede ingresar un camión con carga tan ALTA!' 
            ROLLBACK
        END 

INSERT INTO Camion VALUES ('443-GAS', 100, 'Guadalajara');
INSERT INTO Camion VALUES ('443-GAS', 3000, 'Guadalajara');

SELECT * FROM Camion

DROP TRIGGER T_pesoCamiones
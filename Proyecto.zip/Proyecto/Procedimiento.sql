
CREATE PROCEDURE SP_infoPaquete @Codigo VARCHAR(8) AS
    DECLARE @tipoEnvio VARCHAR(20)
    DECLARE @Direccion VARCHAR(20)
    DECLARE @Peso REAL
    DECLARE @Conductor VARCHAR(20)
    DECLARE @Ruta INT
    DECLARE @RutaCompleta VARCHAR(20)
    DECLARE @RFC VARCHAR(13)
    DECLARE @Placas VARCHAR(20)
    DECLARE @Fecha VARCHAR(10)
    DECLARE @LineaAerea VARCHAR(20)
    DECLARE @CodigoLocal INT
    SET @tipoEnvio = (SELECT Tipo_Envio FROM Paquete WHERE Codigo = @Codigo)
    SET @Direccion = (SELECT Direccion FROM Paquete WHERE Codigo = @Codigo)
BEGIN
    IF @tipoEnvio = 'Nacional'
        BEGIN  
            SET @Peso = (SELECT Peso FROM Paquete WHERE Codigo = @Codigo)
            SET @Conductor = (SELECT Nombre FROM Conductor AS C INNER JOIN Nacional AS N ON C.RFC = N.RFC 
                              WHERE N.Codigo = @Codigo)
            SET @RutaCompleta = (SELECT Nombre FROM Rutas AS R INNER JOIN Nacional AS N ON R.ID_Ruta = N.ID_Ruta 
                                 WHERE N.Codigo = @Codigo)
            SET @RFC = (SELECT C.RFC FROM Conductor AS C INNER JOIN Nacional AS N ON C.RFC = N.RFC 
                        WHERE N.Codigo = @Codigo)
            SET @Conductor = (SELECT Nombre FROM Conductor WHERE RFC = @RFC)
            SET @Placas = (SELECT C.Placa FROM Camion AS C INNER JOIN Conductor_Camion AS CC ON C.Placa = CC.Placa 
                           WHERE CC.RFC = @RFC)
            SET @Fecha = (SELECT Fecha FROM Conductor_Camion WHERE RFC = @RFC AND Placa = @Placas)
            PRINT 'Paquete: ' + @Codigo
            PRINT 'Dirección: ' + @Direccion
            PRINT 'Peso: ' + CAST(@Peso AS VARCHAR) + ' kg.'
            PRINT 'Conductor: ' + @Conductor
            PRINT 'Ruta: ' + @RutaCompleta
            PRINT 'Placas: ' + @Placas
            PRINT 'Fecha: ' + @Fecha
        END
    ELSE 
        BEGIN
            SET @LineaAerea = (SELECT Linea_Aerea FROM Internacional WHERE Codigo = @Codigo)
            SET @CodigoLocal = (SELECT C.Codigo_Local FROM Internacional AS I INNER JOIN C_Local AS C 
                                ON I.Codigo_Local = C.Codigo_Local WHERE I.Codigo = @Codigo)
            PRINT 'Dirección: ' + @Direccion
            PRINT 'Paquete: ' + @Codigo
            PRINT 'Línea aérea: ' + @LineaAerea
            PRINT 'C-Local: ' + CAST(@CodigoLocal AS VARCHAR)
        END
END

SELECT * FROM Nacional
SELECT * FROM Internacional
SELECT * FROM Paquete
EXEC SP_infoPaquete 'AD_42562'
EXEC SP_infoPaquete 'BN_24324'

-- DROP TABLE Paquete;
-- DROP TABLE Paquete_Envio;
-- DROP TABLE Conductor;
-- DROP TABLE Camion;
-- DROP TABLE Nacional;
-- DROP TABLE Internacional;
-- DROP TABLE Conductor_Camion;
-- DROP TABLE C_Local;
-- DROP TABLE Rutas;
-- DROP TABLE RutasConductor;
-- --Crear otro disparador para (envió o paquete) nacional
-- Que al ingresar un nuevo envió, ingrese en otra tabla el id del envió y la ciudad de destino
-- y además muestre cuantos envíos se han hecho a dicha ciudad destino 
-- (en otras palabras que guarde en un campo en número de envíos 
CREATE TRIGGER T_noEnvios 
ON Nacional FOR INSERT AS 
    DECLARE @idEnvio VARCHAR(8)
    DECLARE @CiudadDestino VARCHAR(30)
    DECLARE @noEnvios INT
    SET @idEnvio = (SELECT Codigo FROM INSERTED)
    SET @CiudadDestino = (SELECT Ciudad_Destino FROM INSERTED)
    SET @noEnvios = (SELECT COUNT(Ciudad_Destino) FROM Nacional 
                     GROUP BY Ciudad_Destino HAVING Ciudad_Destino = @CiudadDestino)
    INSERT INTO Paquete_Envio VALUES (@idEnvio, @CiudadDestino)
    BEGIN
        PRINT 'Se han hecho ' + CAST(@noEnvios AS VARCHAR) + ' envios a ' + @CiudadDestino 
    END

SELECT * FROM Paquete_Envio;

--AGREGAR OTRO REGISTRO
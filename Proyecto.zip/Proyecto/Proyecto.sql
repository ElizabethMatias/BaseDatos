
CREATE TABLE Paquete(
    Codigo VARCHAR(8) NOT NULL,
    Direccion VARCHAR(20) NOT NULL,
    Peso REAL NOT NULL,
    Destinatario VARCHAR(20) NOT NULL,
    Fecha_Envio DATE DEFAULT GETDATE(),
    Tipo_Envio VARCHAR(20) NOT NULL,
    CONSTRAINT PK_COD PRIMARY KEY (Codigo),
    CONSTRAINT CHK_COD CHECK (Codigo LIKE '[A-Z][A-Z]_[1-9][1-9][1-9][1-9][1-9]'),
    CONSTRAINT CHK_PESO CHECK (Peso BETWEEN 0 AND 2),
    CONSTRAINT CHK_FECHA CHECK (Fecha_Envio BETWEEN '10/12/2020' AND GETDATE())
);

CREATE TABLE Rutas(
    ID_Ruta INTEGER NOT NULL,
    Nombre VARCHAR(20) NOT NULL,
    CONSTRAINT PK_RUTA PRIMARY KEY (ID_Ruta)
);

CREATE TABLE RutasConductor(
    ID_Ruta INTEGER NOT NULL,
    Nombre VARCHAR(20) NOT NULL,
    CONSTRAINT PK_RUTAC PRIMARY KEY (ID_Ruta)
);

CREATE TABLE C_Local(
    Codigo_Local INTEGER,
    Nombre VARCHAR(20),
    CONSTRAINT PK_COD_LOCAL PRIMARY KEY (Codigo_Local)
);

CREATE TABLE Internacional(
    Codigo VARCHAR(8) NOT NULL,
    Linea_Aerea VARCHAR(20) NOT NULL DEFAULT 'Mexicana',
    Codigo_Local INTEGER NOT NULL,
    Fecha_Entrega DATE,
    CONSTRAINT FK_COD_INT FOREIGN KEY (Codigo) REFERENCES Paquete (Codigo)
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    CONSTRAINT FK_COD_LOCAL FOREIGN KEY (Codigo_Local) REFERENCES C_Local (Codigo_Local)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT CHK_ENTREGA CHECK (Fecha_Entrega >=  '11/12/2020')
);

--los primeros dos caracteres corresponden al apellido paterno; luego, 
--les sigue la inicial del apellido materno y, después, la primera letra del nombre; 
--enseguida  encontrarás los dos dígitos del año, mes y día de nacimiento 
--(dos dígitos por cada categoría) y, por último, está la homoclave, una serie única de 3 caracteres
CREATE TABLE Conductor(
    RFC VARCHAR(13) NOT NULL,
    Nombre VARCHAR(20) NOT NULL,
    Direccion VARCHAR(20) NOT NULL,
    ID_Ruta INTEGER NOT NULL,
    CONSTRAINT PK_RFC PRIMARY KEY (RFC),
    CONSTRAINT FK_RUT_CON FOREIGN KEY (ID_Ruta) REFERENCES RutasConductor (ID_Ruta)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT CHK_RFC CHECK (RFC LIKE '[A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
);

CREATE TABLE Nacional(
    Codigo VARCHAR(8) NOT NULL,
    Ciudad_Destino VARCHAR(20) NOT NULL,
    RFC VARCHAR(13) NOT NULL,
    ID_Ruta INTEGER NOT NULL,
    CONSTRAINT FK_COD_NAC FOREIGN KEY (Codigo) REFERENCES Paquete (Codigo)
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    CONSTRAINT FK_RUT_NAC FOREIGN KEY (ID_Ruta) REFERENCES Rutas (ID_Ruta)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    CONSTRAINT FK_COND_NAC FOREIGN KEY (RFC) REFERENCES Conductor (RFC)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

CREATE TABLE Paquete_Envio(
    Codigo VARCHAR(8) NOT NULL,
    Ciudad_Destino VARCHAR(20) NOT NULL,  
    CONSTRAINT FK_COD_PAQ FOREIGN KEY (Codigo) REFERENCES Paquete (Codigo) 
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
);

CREATE TABLE Camion(
    Placa VARCHAR(7) NOT NULL,
    Carga_MAX INTEGER,
    Ciudad_Resguardo VARCHAR(11) NOT NULL,
    CONSTRAINT PK_PLACA PRIMARY KEY (Placa),
    CONSTRAINT CHK_PLACA CHECK (Placa LIKE '[0-9][0-9][0-9]-[A-Z][A-Z][A-Z]'),
    CONSTRAINT CHK_CARGA CHECK (Carga_MAX BETWEEN 0 AND 4000),
    CONSTRAINT CHK_CUIDAD CHECK (Ciudad_Resguardo IN('CDMX','Monterrey','Guadalajara','Mérida','Tijuana')),
);

CREATE TABLE Conductor_Camion(
    RFC VARCHAR(13) NOT NULL,
    Placa VARCHAR(7) NOT NULL,
    Fecha DATE,
    CONSTRAINT FK_RFC FOREIGN KEY (RFC) REFERENCES Conductor (RFC)
        ON DELETE CASCADE 
        ON UPDATE CASCADE,
    CONSTRAINT FK_PLACA FOREIGN KEY (Placa) REFERENCES Camion(Placa)
        ON DELETE CASCADE 
        ON UPDATE CASCADE
);

-- SELECT * FROM Paquete;
-- SELECT * FROM Conductor;
-- SELECT * FROM Camion;
-- SELECT * FROM Nacional;
-- SELECT * FROM Paquete_Envio;
-- SELECT * FROM Internacional;
-- SELECT * FROM Conductor_Camion;
-- SELECT * FROM C_Local;
-- SELECT * FROM Rutas;
-- SELECT * FROM RutasConductor;

-- DROP TABLE Paquete;
-- DROP TABLE Paquete_Envio;
-- DROP TABLE Conductor;
-- DROP TABLE Camion;
-- DROP TABLE Nacional;
-- DROP TABLE Internacional;
-- DROP TABLE Conductor_Camion;
-- DROP TABLE C_Local;
-- DROP TABLE Rutas;
-- DROP TABLE RutasConductor;

-- DELETE FROM Paquete;
-- DELETE FROM Paquete_Envio;
-- DELETE FROM Conductor;
-- DELETE FROM Camion;
-- DELETE FROM Nacional;
-- DELETE FROM Internacional;
-- DELETE FROM Conductor_Camion;
-- DELETE FROM C_Local;
-- DELETE FROM Rutas;
-- DELETE FROM RutasConductor;

